branch-0 - Виноградов
branch-1 - Яворович
branch-2 - Костиков
branch-3 - Соловей
branch-4 - Смикало
branch-5 - Горбатенко
Команди git
1. git clone <url-репозитория>
2. git checkout -b <название-новой-ветки>
3. git add <название-файла1> <название-файла2> ...
4. git commit -m "Ваш комментарий к изменениям"
5. git push origin <название-ветки>
